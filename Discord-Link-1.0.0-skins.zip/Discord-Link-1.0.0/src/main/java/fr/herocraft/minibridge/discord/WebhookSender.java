package fr.herocraft.minibridge.discord;

import fr.herocraft.minibridge.MiniBridge;
import org.json.simple.JSONArray;
import org.json.simple.JSONObject;

import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.logging.Level;

/**
 * Envoi de messages via Webhook Discord.
 * Plus simple que le bot complet, mais ne peut pas lire les messages entrants.
 */
public class WebhookSender {

    private final MiniBridge plugin;
    private final String webhookUrl;
    private final String username;
    private final ExecutorService executor;

    public WebhookSender(MiniBridge plugin) {
        this.plugin = plugin;
        this.webhookUrl = plugin.getConfig().getString("webhook-url");
        this.username = plugin.getConfig().getString("webhook-username", "MiniBridge");
        this.executor = Executors.newSingleThreadExecutor(r -> {
            Thread t = new Thread(r, "MiniBridge-Webhook");
            t.setDaemon(true);
            return t;
        });
    }

    public void send(String content) {
        JSONObject payload = new JSONObject();
        payload.put("username", username);
        payload.put("content", content);
        sendPayload(payload);
    }

    /**
     * Envoie un embed via le webhook (utilisé pour afficher le skin d'un joueur qui rejoint).
     *
     * @param description texte de l'embed (supporte le markdown Discord, ex: **gras**)
     * @param thumbnailUrl URL de l'image affichée en vignette (ex: tête du skin du joueur), peut être null
     * @param color        couleur de la barre latérale de l'embed (format décimal, ex: 0x57F287)
     */
    @SuppressWarnings("unchecked")
    public void sendEmbed(String description, String thumbnailUrl, int color) {
        JSONObject embed = new JSONObject();
        if (description != null && !description.isEmpty()) embed.put("description", description);
        embed.put("color", color);
        if (thumbnailUrl != null && !thumbnailUrl.isEmpty()) {
            JSONObject thumbnail = new JSONObject();
            thumbnail.put("url", thumbnailUrl);
            embed.put("thumbnail", thumbnail);
        }

        JSONArray embeds = new JSONArray();
        embeds.add(embed);

        JSONObject payload = new JSONObject();
        payload.put("username", username);
        payload.put("embeds", embeds);
        sendPayload(payload);
    }

    private void sendPayload(JSONObject payload) {
        executor.submit(() -> {
            try {
                HttpURLConnection conn = (HttpURLConnection) new URL(webhookUrl).openConnection();
                conn.setRequestMethod("POST");
                conn.setRequestProperty("Content-Type", "application/json");
                conn.setRequestProperty("User-Agent", "MiniBridge/1.0");
                conn.setDoOutput(true);
                conn.setConnectTimeout(5000);
                conn.setReadTimeout(5000);

                String body = payload.toJSONString();
                try (OutputStream os = conn.getOutputStream()) {
                    os.write(body.getBytes(StandardCharsets.UTF_8));
                }

                int code = conn.getResponseCode();
                if (code >= 400 && plugin.isDebug()) {
                    plugin.getLogger().warning("Webhook erreur " + code);
                }
                conn.disconnect();
            } catch (Exception e) {
                if (plugin.isDebug()) plugin.getLogger().log(Level.WARNING, "Erreur webhook", e);
            }
        });
    }

    public void shutdown() {
        executor.shutdownNow();
    }
}
